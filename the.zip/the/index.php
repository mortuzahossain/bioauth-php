<?php

include 'config.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav class="navbar navbar-expand-md bg-dark navbar-default">
        <div class="container container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img height="30px" src="icon.png" alt="Logo"></a>
            </div>
        
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/train.php"><span class="">Train</span></a></li>
                <li><a href="/"><span class="">Test</span></a></li>	
            </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>


    <div class="container">


        <h2>Test Image</h2>
        <br>
        <div class="row">
            <form  method="post" enctype="multipart/form-data">
            <div class="col-md-6">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="box-body">
                    
                    <div class="form-group">
                        <label for="exampleInputPassword2">Image</label>
                        <input type="file" class="form-control" multiple="" name="image">
                    </div>
                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="submit" class="btn btn-primary" name="submit">Test</button>
                </div>
                </form>
                        
            </div>        
        </div>
    </div>



    <br>
    <div class="container">


        <?php
            if(isset($_POST['submit'])){ 


                $extension=array("jpeg","jpg");
                if(isset($_FILES['image'])){
                    $tempFile   = $_FILES['image']['tmp_name'];
                    $filename   = $_FILES['image']['name'];
                    $ext=pathinfo($filename,PATHINFO_EXTENSION);
                    if(in_array($ext,$extension)) {
                        $data = file_get_contents($tempFile);
                        $base64 = base64_encode($data);
                    } else {
                        echo "Image must have to be .jpg";
                        return;
                    }
                } else {
                    echo "Image required";
                    return;
                }

                if(!empty($base64)){

                    $req = array();
                    $req["image"] = $base64;

                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => 'http://127.0.0.1:5000',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>json_encode($req),
                    CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json'
                    ),
                    ));

                    $response = curl_exec($curl);

                    $curl_error = curl_error($curl);
                    curl_close($curl);
                    $responseData = json_decode( $response);
                } else {
                    echo "<pre>Empty Image</pre> ";
                }
            } 
            if(!empty($responseData)){
                
        ?>


        <div class="panel panel-default">
        <div class="panel-heading">Results</div>
        <div class="panel-body">
            <?php if($responseData->RespCode == 100){ ?>
            <div class="col-md-6">
            <p><b>Name: </b> <?=$responseData->userinfo->name?></p>
            <p><b>Email: </b><?=$responseData->userinfo->email?></p>
            <p><b>Fathers Name: </b><?=$responseData->userinfo->fathername?></p>
            <p><b>Mothers name: </b><?=$responseData->userinfo->mothername?></p>
            <p><b>Address: </b><?=$responseData->userinfo->address?></p>
            <p><b>Confidence (0 to 1): </b><?=$responseData->Confidence?></p>
            </div>
            <div class="col-md-6">
                <div class="col-md-6">
                    <p><b>Uploaded Image</b></p>
                    <img src="data:image/jpg;base64,<?=$base64?>" height="100px" width="100px" alt="">
                </div>
                <div class="col-md-6">
                    <p><b>Match Image</b></p>
                    <img src="http://127.0.0.1:5000/image/<?=$responseData->userinfo->id?>" height="100px" width="100px" alt="">
                </div>
                
            </div>
            <?php } else {
                    echo $responseData->RespMsg;
                }?>
        </div>
        </div>


        <?php  }?>



    </div>
    


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


</body>
</html>