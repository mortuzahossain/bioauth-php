<?php

include 'config.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav class="navbar navbar-expand-md bg-dark navbar-default">
        <div class="container container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img height="30px" src="icon.png" alt="Logo"></a>
            </div>
        
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/train.php"><span class="">Train</span></a></li>
                <li><a href="/"><span class="">Test</span></a></li>	
            </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>


    <div class="container">


        <h2>Train Image</h2>
        <br>
        <div class="row">
            <form  method="post" enctype="multipart/form-data">
            <div class="col-md-6">
                <div class="form-group">
                    <label >Name</label>
                    <input type="text" class="form-control" name="name"  required>
                </div>
                <div class="form-group">
                    <label >Email</label>
                    <input type="email" class="form-control" name="email" required >
                </div>
                <div class="form-group">
                    <label >Father Name</label>
                    <input type="text" class="form-control" name="fathername"  required>
                </div>
                <div class="form-group">
                    <label >Mother Name</label>
                    <input type="text" class="form-control" name="mothername"  required>
                </div>
                <div class="form-group">
                    <label >Address</label>
                    <input type="text" class="form-control" name="address" required >
                </div>
                <input type="submit" name="submit" value="UPLOAD" class="btn btn-success">
            </div>
            <div class="col-md-6">
                <div class="upload__box">
                    <div class="upload__btn-box form-group">
                        <label class="upload__btn ">
                        <input type="file" multiple="" name="files[]" data-max_length="20" class="upload__inputfile form-control">
                        </label>
                    </div>
                    <div class="upload__img-wrap"></div>
                </div>
            </div>
            </form>
        </div>
    </div>



    <br>
    <div class="container">

    <h5>Result</h5>
        <pre>

            <?php
                if(isset($_POST['submit'])){ 


                    $name = mysqli_real_escape_string($conn, $_POST['name']);
                    $email = mysqli_real_escape_string($conn, $_POST['email']);
                    $fathername = mysqli_real_escape_string($conn, $_POST['fathername']);
                    $mothername = mysqli_real_escape_string($conn, $_POST['mothername']);
                    $address = mysqli_real_escape_string($conn, $_POST['address']);


                    $error=array();
                    $extension=array("jpeg","jpg");
                    $imageArr = array();
                    foreach($_FILES["files"]["tmp_name"] as $key=>$tmp_name) {
                        $file_name=$_FILES["files"]["name"][$key];
                        $file_tmp=$_FILES["files"]["tmp_name"][$key];
                        $ext=pathinfo($file_name,PATHINFO_EXTENSION);
                    
                        if(in_array($ext,$extension)) {
                            $data = file_get_contents($file_tmp);
                            $base64 = base64_encode($data);
                            array_push($imageArr,$base64);
                        }
                        else {
                            array_push($error,"$file_name, ");
                        }
                    }

                    if(!empty($imageArr)){
                        if(!empty($email)){
                            $sql = "insert into users (name,email,fathername,mothername,address) values ('$name','$email','$fathername','$mothername','$address')";
                            if (mysqli_query($conn, $sql)) {
                                $last_id = mysqli_insert_id($conn);
                            } else {
                                echo "Failed to add the user. Try again with different email";
                                return;
                            }
                        } else {
                            echo "Email required";
                            return;
                        }
    

                        $req = array();
                        $req["userid"] = strval($last_id);
                        $req["images"] = $imageArr;

                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                        CURLOPT_URL => 'http://127.0.0.1:5000/register',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'POST',
                        CURLOPT_POSTFIELDS =>json_encode($req),
                        CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json'
                        ),
                        ));

                        $response = curl_exec($curl);

                        $curl_error = curl_error($curl);
                        curl_close($curl);
                        echo $response;
                    } else {
                        echo "Empty Image";
                    }
                } 


            ?>

        </pre>    
    </div>
    


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script>
        jQuery(document).ready(function () {
  ImgUpload();
});

function ImgUpload() {
  var imgWrap = "";
  var imgArray = [];

  $('.upload__inputfile').each(function () {
    $(this).on('change', function (e) {
      imgWrap = $(this).closest('.upload__box').find('.upload__img-wrap');
      var maxLength = $(this).attr('data-max_length');

      var files = e.target.files;
      var filesArr = Array.prototype.slice.call(files);
      var iterator = 0;
      filesArr.forEach(function (f, index) {

        if (!f.type.match('image.*')) {
          return;
        }

        if (imgArray.length > maxLength) {
          return false
        } else {
          var len = 0;
          for (var i = 0; i < imgArray.length; i++) {
            if (imgArray[i] !== undefined) {
              len++;
            }
          }
          if (len > maxLength) {
            return false;
          } else {
            imgArray.push(f);

            var reader = new FileReader();
            reader.onload = function (e) {
              var html = "<div class='upload__img-box'><div style='background-image: url(" + e.target.result + ")' data-number='" + $(".upload__img-close").length + "' data-file='" + f.name + "' class='img-bg'><div class='upload__img-close'></div></div></div>";
              imgWrap.append(html);
              iterator++;
            }
            reader.readAsDataURL(f);
          }
        }
      });
    });
  });

  $('body').on('click', ".upload__img-close", function (e) {
    var file = $(this).parent().data("file");
    for (var i = 0; i < imgArray.length; i++) {
      if (imgArray[i].name === file) {
        imgArray.splice(i, 1);
        break;
      }
    }
    $(this).parent().parent().remove();
  });
}
    </script>


</body>
</html>