<?php

$servername = "127.0.0.1";
$username = "admin";
$password = "p1234";
$database = "bioauth";

$conn = mysqli_connect($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>